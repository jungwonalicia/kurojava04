package 배열;

public class 반복문FOR별 {
	public static void main(String[] args) {
	for (int i = 0; i < 3; i++) {
		System.out.print(i + ": ");
		for (int j = 0; j < 10; j++) {
			System.out.print("★");
		}
		System.out.println();
	}	
	}
}

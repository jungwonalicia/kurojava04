package 배열;

public class 배열테스트1 {

	public static void main(String[] args) {
		//new => 복사
		//배열(array): 늘어놓았다. 진열.
		int[] jumsu = {55, 77, 88, 22};
		System.out.println(jumsu[1]);
		System.out.println(jumsu[3]);
		jumsu[0] = 66;
		System.out.println(jumsu[0]);
		System.out.println();
		for (int x : jumsu) {
			System.out.println(x);
		}
		
		
		
		
		
		
		
		
		
		
	}

}

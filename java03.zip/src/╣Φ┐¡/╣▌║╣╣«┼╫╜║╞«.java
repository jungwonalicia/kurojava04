package 배열;

public class 반복문테스트 {
	public static void main(String[] args) {
//		for(시작값; 조건식; 증감값) {
		for(int i = 0; i < 100; i++) {
			System.out.println("★");
		}
	}
}

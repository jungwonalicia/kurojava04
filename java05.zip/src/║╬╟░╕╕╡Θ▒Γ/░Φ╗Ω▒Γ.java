package 부품만들기;

public class 계산기 {
	//x, y는 입력값을 잠깐 넣어서
	//계산할 목적으로 사용
	//메소드의 정의와 호출하는 부분에 
	//입력값인 데이터 전달할 목적으로 사용
	//다리역할(매개변수, parameter, 파라메터)
	public int add(int x, int y) {
		 return x + y;
	}
	public int minus(int x, int y) {
		return x - y;
	}
	public int mul(int x, int y) {
		return x * y;
	}
	public double mul(int x, double y) {
		return x * y;
	}
	public int div(int x, int y) {
		return x / y;
	}
	//두 수의 곱하기(mul),  나누기(div)
	
	
	
	
	
	
	
	
	
	
}

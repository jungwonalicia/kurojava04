package 인터페이스;

public interface Mouse {
	public abstract void 볼록튀어나오다();
	void 양쪽버튼을클릭하다();
}

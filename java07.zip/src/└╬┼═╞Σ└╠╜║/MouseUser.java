package 인터페이스;

public class MouseUser {

	public static void main(String[] args) {
		사과마우스 사과 = new 사과마우스();
		사과.볼록튀어나오다();
		사과.양쪽버튼을클릭하다();
	}

}

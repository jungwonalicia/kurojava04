package 인터페이스;

public interface MemberInterface {
	void insert();
	void update();
	void delete();
	void select();	
}

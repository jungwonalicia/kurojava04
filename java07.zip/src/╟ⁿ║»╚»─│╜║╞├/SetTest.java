package 형변환캐스팅;

import java.util.HashSet;

public class SetTest {

	public static void main(String[] args) {
		HashSet bag = new HashSet();
		bag.add("프로그래머");
		bag.add("디자이너");
		bag.add("기획자");
		System.out.println(bag);
	}
}







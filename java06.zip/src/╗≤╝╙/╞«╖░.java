package 상속;

public class 트럭 extends 자동차{
	//트럭
//	- 파랑, 누비다트럭
//	- 짐을 나르다.
	public void move() {
		System.out.println("짐을 나르다.");
	}
}

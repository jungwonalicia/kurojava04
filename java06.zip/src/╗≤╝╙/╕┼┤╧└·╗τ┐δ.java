package 상속;

public class 매니저사용 {

	public static void main(String[] args) {
		Manager m1 = new Manager("홍길동", "구로구", 100, 880107, 100);
		Manager m2 = new Manager("김길동", "종로구", 200, 890107, 150);
		System.out.println(m1);
	}

}

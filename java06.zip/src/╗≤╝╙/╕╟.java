package 상속;

public class 맨 extends 사람{
	//멤버변수 2개, 멤버메소드 2개
	int strong;
	
	public void run() {
		System.out.println("빨리 달리다.");
	}
}

package 상속;

public class Bank {
	public double 대출이자를받다() {
		return 0;
	}
}

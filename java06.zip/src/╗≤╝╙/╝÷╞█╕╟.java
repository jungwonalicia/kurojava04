package 상속;

public class 수퍼맨 extends 맨{
	//멤버변수 3, 멤버메소드 3
	boolean fly;
	
	public void flyHeight() {
		System.out.println("지구 밖까지 날 수 있다.");
	}
}

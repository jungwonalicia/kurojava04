package 상속;

public class 자동차 {
//	자동차
//		- 색, 이름
	String color;
	String name;
	
//		- 출발하다, 멈추다.
	public void start() {
		System.out.println("출발하다.");
	}
	public void stop() {
		System.out.println("멈추다.");
	}
}







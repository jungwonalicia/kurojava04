package 상속;

public class 세단 extends 자동차{
//	세단
//	- 빨강, 세련세단
//	- 조용히창문이 열리다.
	public void window() {
		System.out.println("조용히창문이 열리다.");
	}
}

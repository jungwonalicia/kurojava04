package 상속;

public class 대학생 extends 학생{
	
	@Override  //Annotation(표시), 어노테이션
	public void 공부하다() {
		System.out.println("취업 공부를  하다.");
	}
}

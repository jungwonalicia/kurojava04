package 상속;

public class BadBank extends Bank{
	@Override
	public double 대출이자를받다() {
		return 10.0;
	}
}

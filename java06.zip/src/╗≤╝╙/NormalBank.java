package 상속;

public class NormalBank extends Bank{
	@Override
	public double 대출이자를받다() {
		return 5.0;
	}
}

package 상속;

public class 수퍼맨사용 {

	public static void main(String[] args) {
		수퍼맨 superMan = new 수퍼맨();
		superMan.age = 100; //사람
		superMan.fly = true; //수퍼맨
		superMan.strong = 200; //맨
		
		superMan.sleep();
		superMan.run();
		superMan.flyHeight();
		
		
		
		
		
		
		
		 
	}

}

package 상속;

public class 사람 {
	//정적특징
	String name;
	int age;
	
	//동적특징
	public void sleep() {
		System.out.println("잠자다.");
	}
	public void talk() {
		System.out.println("말하다.");
	}
}

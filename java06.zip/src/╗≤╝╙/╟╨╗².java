package 상속;

public class 학생 {
	public void 공부하다() {
		 System.out.println("공부하다.");
	}
}

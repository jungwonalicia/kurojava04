package 상속;

public class GoodBank extends Bank{
	@Override
	public double 대출이자를받다() {
		return 2.0;
	}
}

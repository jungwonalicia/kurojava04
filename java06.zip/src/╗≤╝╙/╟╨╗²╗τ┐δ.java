package 상속;

public class 학생사용 {

	public static void main(String[] args) {
		초등학생 초등 = new 초등학생();
		초등.공부하다();
		중학생 중등 = new 중학생();
		중등.공부하다();
		고등학생 고등 = new 고등학생();
		고등.공부하다();
		대학생 대학 = new 대학생();
		대학.공부하다();
		
		
	}

}

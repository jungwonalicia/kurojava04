package 원래패키지;

public class 직원 {
	private String 주민번호;
	protected String 주소;
	int 월급;
	public String 이름; 
	
	public void play() throws Exception{
		int[] num = {1, 2, 3};
		num[3] = 100;
	}
}






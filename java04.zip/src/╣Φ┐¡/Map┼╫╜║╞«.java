package 배열;

import java.util.HashMap;

public class Map테스트 {

	public static void main(String[] args) {
		HashMap doing = new HashMap();
//		Day day = new Day();
//		day.set("자바공부하기");
//		doing.put(1, day);
//		
//		Day day2 = (Day)doing.get(1);
//		day2.show();
		
	}

}

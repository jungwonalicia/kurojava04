package control;

import java.util.Scanner;

public class InputTest2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("당신의 이름은 : ");
		String name = sc.next();
	}
}

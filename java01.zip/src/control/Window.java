package control;

import javax.swing.JFrame;

public class Window {

	public static void main(String[] args) {
		JFrame f = new JFrame();
		f.setSize(500, 500);
		f.setVisible(true);
	}

}

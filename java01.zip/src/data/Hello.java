package data;

public class Hello {

	public static void main(String[] args) {
		System.out.println("반갑습니다.");
	}

}

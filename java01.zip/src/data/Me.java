package data;

public class Me {

	public static void main(String[] args) {
		//comment, 주석(설명)
		//새로만들기(컨트롤+n)
		//한줄삭제(컨트롤+d) -> 이전명령취소(컨트롤+z)
		System.out.println("헬로우 월드...");
		//syso, sysout 컨트롤+spaceBar(자동완성)
		System.out.println();
	}

}

package control;

public class Second {

	public static void main(String[] args) {
		//어제의 날씨 : 10
		int yesterday = 10;
		
		//오늘은 어제보다 : 5.5 낮다.
		//자동완성 컨트롤+스페이스바
		double today = yesterday - 5.5;
		
		//오늘의 요일..
		char weekday = '일';
		
		//오늘은 비가 오나요..
		boolean rain = true; //false
		
		System.out.println("어제의 날씨는 " + yesterday);
		System.out.println("오늘의 날씨는 " + today);
		System.out.println("오늘은 " + weekday);
		System.out.println("오늘은 비가 오나요?? " + rain);
		
		//저장: 컨트롤+s
		//실행: 컨트롤+f11
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
